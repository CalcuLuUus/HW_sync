public abstract class Expression {
    public abstract boolean interpret(String context);
}
