public abstract class Order {
    public abstract void excute();
}
