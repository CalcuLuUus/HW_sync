public abstract class func {
    public abstract void Use();
}
