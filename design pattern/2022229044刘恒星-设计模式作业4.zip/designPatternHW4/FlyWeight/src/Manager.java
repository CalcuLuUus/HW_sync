public class Manager extends User{
    public Manager(){
        super();
        id = 2;
    }
}
