public class func1 extends func{

    @Override
    public void Use() {
        System.out.println("using func1");
    }
    
}
