public class Customer extends User {

    public Customer(){
        super();
        id = 1;
    }
    
}
