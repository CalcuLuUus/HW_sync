public class func2 extends func{
    @Override
    public void Use() {
        System.out.println("using func2");
    }
}
