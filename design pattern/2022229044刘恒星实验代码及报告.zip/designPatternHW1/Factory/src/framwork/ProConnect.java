package framwork;
public abstract class ProConnect {
    public abstract void use();
}
