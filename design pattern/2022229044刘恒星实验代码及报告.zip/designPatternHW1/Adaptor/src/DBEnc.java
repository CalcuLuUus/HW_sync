public abstract class DBEnc {
    public abstract String Enc();
}
