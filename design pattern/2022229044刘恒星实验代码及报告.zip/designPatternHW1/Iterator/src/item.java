public class item {
    private int id;
    public item(int id)
    {
        this.id = id;
    }

    @Override
    public String toString() {
        return "item [id=" + id + "]";
    }
}
