public interface MyIterator {
    public abstract boolean hasNext();
    public abstract Object[] next();
    public abstract void setCntOfPage(int num);
}
