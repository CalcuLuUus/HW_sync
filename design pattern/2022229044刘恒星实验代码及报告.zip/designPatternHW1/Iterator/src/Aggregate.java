public interface Aggregate {
    public abstract MyIterator iterator();
}
