public class App {
    public static void main(String[] args) throws Exception {
        AbAlgo algo1 = new Algo1Apt();
        AbAlgo algo2 = new Algo2Apt();
        algo1.display();
        algo2.display();
    }
}
