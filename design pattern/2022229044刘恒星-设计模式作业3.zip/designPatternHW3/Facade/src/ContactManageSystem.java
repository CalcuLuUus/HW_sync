public class ContactManageSystem implements ManageSystem{

    @Override
    public void transInfo() {
        System.out.println("Contact info trans......");
    }
    
}
