public class MsgManageSystem implements ManageSystem{

    @Override
    public void transInfo() {
        System.out.println("Msg info trans......");
    }
    
}
