public interface ManageSystem {
    public void transInfo();
}
