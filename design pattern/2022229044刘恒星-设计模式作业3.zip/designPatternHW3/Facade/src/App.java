public class App {
    public static void main(String[] args) throws Exception {
        BackupFacade backupFacade = new BackupFacade();
        backupFacade.backup();
    }
}
