public abstract class Mediator {
    public abstract void send(String msg, SubSystem subSystem);
}
