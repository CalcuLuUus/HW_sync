public abstract class SubSystem {
    protected Mediator mediator;
    public SubSystem(Mediator mediator){
        this.mediator = mediator;
    }
}
