public abstract class Observer {
    protected Generator generator;
    public abstract void update();
}
