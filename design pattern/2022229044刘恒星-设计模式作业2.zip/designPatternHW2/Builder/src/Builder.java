public abstract class Builder {
    public abstract void makeBody();
    public abstract void makeEng();
    public abstract void makeWheel();
    public abstract void makeOther();
}
