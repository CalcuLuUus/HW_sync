public class Triangle extends shape{
    @Override
    public void draw() {
        System.out.println("I am triangle");
    }

    @Override
    public void erase() {
        System.out.println("triangle has been erased");
    }
    
}
