public class circle extends shape{

    @Override
    public void draw() {
        System.out.println("I am circle");
    }

    @Override
    public void erase() {
        System.out.println("circle has been erased");
    }
    
}
