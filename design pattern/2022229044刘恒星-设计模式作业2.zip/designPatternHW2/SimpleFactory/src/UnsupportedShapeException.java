
public class UnsupportedShapeException extends Exception{
    public UnsupportedShapeException(){
        super("No such shape");
    }
}
