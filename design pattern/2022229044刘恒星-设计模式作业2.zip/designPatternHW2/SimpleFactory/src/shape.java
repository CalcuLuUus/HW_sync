public abstract class shape {
    public abstract void draw();
    public abstract void erase();
}
