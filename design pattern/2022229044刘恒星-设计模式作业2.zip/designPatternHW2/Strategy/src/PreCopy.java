public class PreCopy implements Algorithm{
    private String algoName = "Pre_Copy";
    @Override
    public void use() {
        System.out.println("Using Algorithm: " + algoName);
    }
    
}
