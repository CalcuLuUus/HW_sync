public class PostCopy implements Algorithm{
    private String algoName = "Post_Copy";
    @Override
    public void use() {
        System.out.println("Using Algorithm: " + algoName);
    }
}
