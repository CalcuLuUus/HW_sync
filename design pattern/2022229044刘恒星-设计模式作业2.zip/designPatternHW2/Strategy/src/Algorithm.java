public interface Algorithm {
    public abstract void use();
}
