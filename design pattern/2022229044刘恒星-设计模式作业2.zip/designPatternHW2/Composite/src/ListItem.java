public abstract class ListItem {
    public abstract String getName();
    public abstract void printInfo(String pre);
    public void print(){
        printInfo("");
    }
}
