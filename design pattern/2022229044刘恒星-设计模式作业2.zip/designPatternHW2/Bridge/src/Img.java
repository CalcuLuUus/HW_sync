public abstract class Img {
    public abstract void imgOpen();
    public abstract void imgClose();
}
