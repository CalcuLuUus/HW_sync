public class Texture extends Filter{

    public Texture(Img img) {
        super(img);
    }

    public void texture(){
        System.out.println("Texture......");
    }
    
}
