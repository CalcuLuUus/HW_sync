<!DOCTYPE html>
<html>
	<head>
		<title>Rancid Tomatoes</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<div id="banner">
			<img src="images/rancidbanner.png" alt="Rancid Tomatoes" />
<?php


?>
		</div>
